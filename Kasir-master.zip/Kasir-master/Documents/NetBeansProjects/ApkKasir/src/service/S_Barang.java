/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;

import java.util.List;
import model.M_barang;

/**
 *
 * @author aryam
 */
public interface S_Barang {
    void tambahData (M_barang mod_bar);
    void perbaruiData (M_barang mod_bar);
    void hapusData (M_barang mod_bar);
    
    M_barang getByid (String id_produk);
    
    List<M_barang> getDataByID();
    List<M_barang> getData();
    
    List<M_barang> pencarian(String id_produk);
    List<M_barang> pencarian2(String id_produk);
    
    String nomor();
    String nomor2();
}
